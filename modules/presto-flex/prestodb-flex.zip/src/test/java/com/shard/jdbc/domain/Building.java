package com.shard.jdbc.domain;

/**
 * Created by roy@warthog.cn on 2015-12-24 11:27.
 */
public class Building {

    private Integer id;
    private String name;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
